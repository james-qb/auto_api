import org.testng.annotations.Test;

public class TestDemo {
    @Test

    public void testDemo(){
        System.out.println("2021年加油");

    }

}